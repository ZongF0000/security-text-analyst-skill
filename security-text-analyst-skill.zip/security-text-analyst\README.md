# security-text-analyst

单机安全文本研判提示词包（PROMPT_PACK_V0）的 DSH skill 封装。

- **完整保留**：`pack/` 下是原始 14 个文件，一字未改，可随时还原为完整 prompt。
- **按需加载**：`SKILL.md` 是短入口（目录表 + 装配规则），Agent 只读当前场景需要的文件，避免全量注入上下文。
- **可溯源**：所有结论绑定证据 ID、`quote` 逐字摘录，枚举封闭、两阶段（先事实后报告）。

## 目录结构

```
security-text-analyst/
├── SKILL.md          # 短入口：铁律 + 目录表 + 装配规则 + 导出说明
├── pack/             # 原始 14 个文件（一字不改，可还原）
│   ├── 01_MASTER_PROMPT.md
│   ├── 02_BASE.md
│   ├── 03_MODULE_A.md
│   ├── 04_MODULE_B.md
│   ├── 05_MODULE_C.md
│   ├── 06_TASK_INJECTOR.md
│   ├── 07_REPORT_SPEC.md
│   ├── 08_ADAPTER_MODEL_A.md
│   ├── 09_ADAPTER_MODEL_B.md
│   ├── 10_WORKFLOW.md
│   ├── 11_ACCEPTANCE_TESTS.md
│   ├── 12_VARIABLES.md
│   ├── 13_SKILL_TEMPLATE.md
│   └── 14_SKILL_REFS.md
└── README.md         # 本文件
```

## 安装（到 DSH）

DSH 的 skill 由 `@deepseek-ai/dsh-skill-filesystem` 从「skill root」自动发现。把本目录（或整个 `security-text-analyst/`）放进任一 skill root 即可，无需重启：

| 层级 | 路径 |
|---|---|
| 项目级 | `<项目根>/.dsh/skills/` 或 `<项目根>/.agents/skills/` |
| 用户级 | `~/.dsh/skills/`（即 `$DSH_HOME/skills`）或 `~/.agents/skills/` |
| 自定义 | 在 `dsh-skill-filesystem` 的 `customSkillDirs` 里配置的目录 |

放好后，新会话的 skill 目录里会出现 `security-text-analyst`，需要时让 Agent 加载它。

## 使用

1. 需要研判安全文本时，加载本 skill。
2. Agent 按 `SKILL.md` 的「装配规则」只读需要的文件：
   - 短材料只要 JSON → `02`（§3 §5）+ `03`
   - 要报告 → 加 `04` + `07`
   - 长材料 → 加 `09` + `08`
   - 有追加要求 → 加 `05`
3. 大文件（`02/04/06/07/08/10/11`）用 read 的 `offset`/`limit` 分页读，或先 grep 定位章节。

## 还原为完整 prompt

需要「把插件还原成一段可直接粘贴进任意 LLM 的完整 prompt」时，按 `06_TASK_INJECTOR.md` 第 9 节的八段骨架，把 `pack/` 里的原文拼起来即可；`SKILL.md` 末尾的「导出完整 prompt」一节给出了八段顺序。

## 分发（上传 / 联网下载）

三种方式任选，详见安装步骤：

1. **Git 仓库**（推荐）：把本目录推到 GitHub/GitLab，其他机器 `git clone` 到 skill root。
2. **zip 打包**：把本目录打成 zip，上传到文件服务器/网盘，其他机器下载后解压到 skill root。
3. **npm 包**：发布为 npm 包（见 `package.json`），其他机器 `npm install` 后把 skill 目录复制/软链到 skill root，或把 `customSkillDirs` 指向包内目录。

> 注意：skill 的发现机制是「本地文件系统 skill root」，不是 `node_modules`。npm 包只是「传输载体」，落地仍需放到 skill root（或配置 `customSkillDirs`）。
