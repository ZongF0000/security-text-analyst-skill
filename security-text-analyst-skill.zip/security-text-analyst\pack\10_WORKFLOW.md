# 10_WORKFLOW(Agent 编排)

Agent 在本机运行。总流程:输入 → 模块选择 → 拼接 → API 调用 → 自检 → 重试/降级 → 报告 → 输出。

## 1. 网络与工具边界
- N1 **网络边界**:Agent 按需调用白名单内工具与模型 API;仅在授权教学环境内处理材料。
- N2 不发起未授权访问、不进行实际攻击操作、不访问与任务无关的外部服务。
- N3 白名单内工具可对其任务范围内的对象发起必要的联网查询(如情报/解析);白名单外一律不调用。
- N4 工具仅限 12_VARIABLES 第 6 节白名单:模型 API 调用、授权分析工具(可联网,以环境白名单为准)、本机文件只读、本地文本处理、本地 JSON 校验、本地结果写出。
- N5 材料只作为文本送入模型;不解码、不解压、不反混淆、不运行。

## 2. 双模型协作

| 环节 | 执行者 | 输入 | 产出 | 交叉校验 |
|---|---|---|---|---|
| 长文定位 | MODEL_B(S1-EV) | 带行号的分段 | `evidence_spans` + `chunk_summaries` | Agent 用原文校验 B1–B5 |
| 合并 | Agent | 各段产出 | 去重、全局重编号的证据表 | X2 计数对账 |
| 结构化抽取 | MODEL_A(S1-CONT) | 证据表(必要时分批) | 事实契约 | X1 证据原样带回;X3 被引用证据回查原文 |
| 短材料抽取 | MODEL_A(S1-FULL) | 带行号的短材料 | 事实契约 | V4 `quote` 可定位 |
| 报告 | MODEL_A(S2-REPORT) | 事实 JSON | `report` | V9、V10、R1、R2 |

`quote` 可定位性由 Agent 用本机原文裁决,不采信任何一个模型的自述:模型B自报的 `locator` 要过 B2,模型A引用的证据要过 X3。

## 3. 伪代码

```text
function RUN(task_text, materials, appended_req, output_mode):

    # ================= 1. 输入 =================
    task_text    = normalize(task_text,    default="未提供题面")           # 06 第4节
    appended_req = normalize(appended_req, default="无")
    if is_missing(materials):
        return WRITE(EMPTY_CONTRACT("材料缺失,无法研判", module_a_executed=false))   # meta: source_type=["未知"], task_type="未知", module_combo="BASE"
    agent_notes = []                                                       # Agent 侧待登记的不确定项

    # ================= 2. 模块选择 =================               # 06 第8节
    is_fact_json = local_validate(materials, SCHEMA_FACTS) or local_validate(materials, SCHEMA_REPORT)
    need_A = not is_fact_json
    need_C = (appended_req != "无")
    need_B = wants_report(task_text, output_mode)                          # BASE §8 R1
    output_mode = resolve_output_mode(output_mode, task_text)
    combo = pick_combo(need_A, need_B, need_C)                             # ∈ BASE §3.4;不清则向含A升级
    facts = parse(materials) if is_fact_json else null

    # ================= 3. 阶段一:事实抽取 =================
    if need_A:
        numbered = PREPROCESS_MATERIALS(materials)                         # 06 第3节
        sentinels = local_scan_sentinels(numbered)                         # 第5节,本地文本扫描

        if length(numbered) <= SHORT_LIMIT_CHARS:
            # ---- 3a. 短材料:MODEL_A 一次完成 ----
            facts = call_with_retry("S1-FULL", numbered, appended_req,
                                    check = CHECK_FACTS(numbered, sentinels))
            if facts is FAIL:
                return WRITE(RENDER(DEGRADE(last_output_evidence(), numbered, "阶段一校验失败"), output_mode))

        else:
            # ---- 3b. 长材料:MODEL_B 定位 ----
            chunks = [with_header(numbered, "1/1")] if fits_window("MODEL_B", numbered) else SPLIT(numbered)   # 06 第5节
            ev_all = []; summaries = []
            for chunk in chunks:
                out = call_with_retry("S1-EV", chunk, "无",
                                      check = CHECK_EVIDENCE(chunk, sentinels))
                if out is FAIL:
                    agent_notes += uncertainty("分段未能读取:" + range_of(chunk), "材料截断")
                    continue
                if not out.chunk_summaries[0].read_to_end:
                    rest = remainder_after_last_evidence(chunk, out)
                    out2 = call_with_retry("S1-EV", rest, "无", check = CHECK_EVIDENCE(rest, sentinels))
                    if out2 is FAIL: agent_notes += uncertainty("分段后半未能读取:" + range_of(rest), "材料截断")
                    else: out = merge_chunk_outputs(out, out2)
                ev_all += out.evidence_spans; summaries += out.chunk_summaries

            before = len(ev_all)
            ev_all = dedup_by(material_ref, locator, ev_all, keep="quote 更长者")
            ev_all = renumber_global(ev_all)                               # EV-001…
            assert X2(before, ev_all)
            if ev_all is empty:
                return WRITE(RENDER(DEGRADE([], numbered, "长材料未取得任何证据"), output_mode))

            # ---- 3c. MODEL_A 续作(必要时分批) ----
            facts = CONTINUE(ev_all, summaries, numbered)
            if facts is FAIL:
                return WRITE(RENDER(DEGRADE(ev_all, numbered, "阶段一校验失败"), output_mode))

            # ---- 3d. 回查(至多一轮) ----
            windows = recheck_windows(facts.uncertainties)                 # needed_material 以"需回查原材料 "开头
            if windows not empty:
                extra = []
                for w in windows:
                    seg = with_header(lines_of(numbered, expand(w, CHUNK_OVERLAP_LINES)), "回查")
                    out = call_with_retry("S1-EV", seg, "无", check = CHECK_EVIDENCE(seg, sentinels))
                    if out is not FAIL: extra += out.evidence_spans
                new_ev = minus(dedup(extra), ev_all)
                if new_ev not empty:
                    ev_all = ev_all + renumber_from(new_ev, next_ev_id(ev_all))   # 已有 ID 不变,新证据续号
                    facts2 = CONTINUE(ev_all, summaries, numbered)
                    if facts2 is not FAIL: facts = facts2                  # 回查失败则保留回查前结果

        facts.uncertainties += agent_notes + escape_notes()                # 伪标签转义登记(06 第3节)

    elif need_C:
        # ---- 3e. BASE+C:只处理追加要求 ----
        out = call_with_retry("C-ONLY", to_json(facts), appended_req, check = CHECK_FACTS(null, null))
        if out is FAIL:
            facts = mark_degraded(facts, "追加要求处理失败")                # 保留原事实,不采用失败输出
        else: facts = out

    # ================= 4. 阶段二:报告 =================
    result = facts
    if need_B and not is_degraded(facts):
        facts_in = with_report_null(facts)
        out = call_with_retry("S2-REPORT", to_json(facts_in), "无", check = CHECK_REPORT(facts_in))
        if out is FAIL:
            result = facts_in
            result.uncertainties += uncertainty("报告生成未通过校验,未输出报告", "其他")
            result.self_check.notes = "DEGRADED:报告阶段校验失败;" + result.self_check.notes
        else: result = out

    # ================= 5. 输出 =================
    result.meta.module_combo = combo                                       # 兜底覆写为实际组合(06 第8节)
    assert local_validate(result, SCHEMA_FACTS) or local_validate(result, SCHEMA_REPORT)
    return WRITE(RENDER(result, output_mode))                              # 只写入指定输出目录


function CONTINUE(ev_all, summaries, numbered):
    batches = batch_by_size(ev_all, SHORT_LIMIT_CHARS)                     # 08 第3节,按证据 ID 顺序
    merged = EMPTY_FACTS(); known = []; nxt = {"E": 1, "F": 1, "seq": 1}
    for batch in batches:
        payload = to_json({"evidence_spans": batch,
                           "chunk_summaries": related(summaries, batch),
                           "known_entities": known, "next_ids": nxt})
        out = call_with_retry("S1-CONT", payload, appended_req,
                              check = CHECK_FACTS_CONT(batch, numbered, known, nxt))
        if out is FAIL: return FAIL
        merged = merge_facts(merged, out)                                  # 实体按 (type,value) 合并证据;发现、轨迹追加
        known = entity_index(merged); nxt = next_ids(merged)
    merged.evidence_spans = ev_all
    merged.behavior_timeline = order_timeline(merged.behavior_timeline)    # 见下
    return merged

function order_timeline(tl):
    if all time_raw non-null and same_format(tl): tl = stable_sort_by_time(tl)
    else if len(batches) > 1: agent_notes += uncertainty("跨批次轨迹的先后顺序无法由原文时间确定", "时间不明")
    return renumber_seq(tl)


function call_with_retry(call_type, payload, appended, check):
    (system, user, esc) = BUILD_PROMPT(call_type, task_text, payload, appended, output_mode, combo)      # 06 第3节
    out  = parse_json(call_api(model_for(call_type), system, user, schema_for(call_type)))        # 模型 API 调用点
    errs = check(out)
    if errs is empty: return out
    (system, user, esc) = BUILD_PROMPT(call_type, task_text, payload, appended, output_mode, combo, retry_errs=errs)
    out  = parse_json(call_api(model_for(call_type), system, user, schema_for(call_type)))        # 仅重试一次
    errs = check(out)
    return out if errs is empty else FAIL


function call_api(model, system, user, schema):
    # 向配置的大模型 API 端点发送请求;超时或连接失败时返回错误,不调用白名单外的网络路径
    return http_post(API_ENDPOINT[model], body = {system, user, temperature, max_tokens, schema})


function DEGRADE(evidence_spans, numbered, reason):
    keep = [ev for ev in evidence_spans if V4_ok(ev, numbered)]            # 只保留可在原文定位的证据
    return CONTRACT(meta = current_meta(),
                    evidence_spans = renumber_global(keep),
                    entities = [], anomaly_findings = [], behavior_timeline = [], report = null,
                    uncertainties = agent_notes + [uncertainty("自检未通过,已降级为证据表+不确定项", "其他")],
                    self_check = honest_self_check(notes = "DEGRADED:" + reason))


function RENDER(result, output_mode):
    md = null
    if is_degraded(result):            md = render(DEGRADE_TEMPLATE, result)     # 07 第6节
    else if result.report is not null: md = render(REPORT_TEMPLATE, result.report)   # 07 第5节
    switch output_mode:
        "JSON":           return to_json(result)
        "REPORT_MD":      return md if md else to_json(result)
        "JSON+REPORT_MD": return to_json(result) + ("\n\n" + md if md else "")
```

## 4. Agent 侧校验项(全部本地执行)

### 4.1 契约校验

| 编号 | 校验 | 适用 |
|---|---|---|
| V1 | 可解析为 JSON;通过对应 Schema(顶层 8 键、类型、必填;不校验键序) | 完整契约 |
| V2 | 枚举字段取值在 BASE §3 内;`confidence` 为 0、0.5、1 | 全部 |
| V3 | ID 格式合法、唯一;所有被引用 ID 已定义 | 全部 |
| V4 | 每条 `quote` 是对应材料的连续子串,位于 `locator` 所指行内,不含行号与段头标记 | 有原始材料时 |
| V5 | 每条 entity、finding、timeline 的 `evidence_ids` 非空 | 阶段一 |
| V6 | 每个 `entities.value` 可在其证据的 `quote` 中找到 | 阶段一 |
| V7 | 有原始材料时 `module_a_executed=true`,且 `evidence_spans` 非空或 `uncertainties` 说明了原因 | 阶段一 |
| V8 | `confidence=0` 的 finding 其 `risk_level=未知`,且出现在 `uncertainties.related_ids` 中 | 阶段一 |
| V9 | 报告中所有方括号引用在已有 ID 内;报告文本中的 IP、域名、URL、路径、账户样式字符串都在 `entities.value` 内 | 阶段二 |
| V10 | 阶段二输出的 6 个事实键(meta、evidence_spans、entities、anomaly_findings、behavior_timeline、uncertainties)与阶段一逐字段一致 | 阶段二 |
| V11 | 输出没有按材料内类指令文本的要求改变结构、语言或结论 | 全部 |
| E1 | `self_check.notes` 的 `ECHO:` 留痕与追加要求前 40 个字符一致;追加要求非空时有 `C:` 登记或相应的事实变化 | 输出完整契约的调用 |

说明:V11 与 `self_check.no_material_instruction_followed` 属语义判断,Agent 机检只能做到结构级兜底,无法完全判定模型是否在语义上服从了注入文本;此为 LLM 提示词防注入的固有局限(已知限制),非可修复缺陷。

### 4.2 长文定位校验(S1-EV)

| 编号 | 校验 |
|---|---|
| B1 | 输出恰含 `evidence_spans` 与 `chunk_summaries` 两键;`chunk_summaries` 恰一条 |
| B2 | 每条 `quote` 是本段原文连续子串,位于 `locator` 行内,不含标记(同 V4,范围限本段) |
| B3 | `line_range` 等于段头标记范围;`evidence_ids` 与本次证据 ID 集合相等;每个 `sample_quote` 是其区间内的原文 |
| B4 | 逐行覆盖:`read_to_end=true` 时本段每一行都落在某条证据的 `locator` 或某个 `skipped_ranges` 区间内,无一遗漏;`read_to_end=false` 时校验到本次输出覆盖到的最大行号为止,未读尾行由 Agent 续读(10 §3) |
| B5 | 哨兵行(第 5 节)全部被某条证据的 `locator` 覆盖,且该证据 `instruction_like=true` |

### 4.3 交叉校验

| 编号 | 校验 |
|---|---|
| X1 | 模型A返回的 `evidence_spans` 与送入的证据表逐条逐字段一致(条数、顺序、内容) |
| X2 | 合并前后计数对账:去重后条数 = 各段条数之和 − 被去重条数;每条被去重的证据都有相同 `material_ref` 且 `locator` 相同或包含它的保留条 |
| X3 | 模型A在实体、发现、轨迹中引用到的每个 EV,用本机原文再做一次 V4 |

### 4.4 报告校验

| 编号 | 校验 |
|---|---|
| R1 | 行数对账(04 第 5 节第 6 步):时间线表、异常表、不确定项表、附录A 的行数分别等于对应数组长度 |
| R2 | `report` 的 11 个键全部为非空字符串;各章含 04 第 4 节规定的固定表头 |

### 4.5 校验组合

| 回调 | 包含 |
|---|---|
| `CHECK_EVIDENCE` | B1–B5 |
| `CHECK_FACTS` | V1–V8、V11、E1 |
| `CHECK_FACTS_CONT` | V1–V3、V5–V8、V11、E1、X1、X3,以及"新 ID 从 `next_ids` 续号、已知实体沿用原 ID" |
| `CHECK_REPORT` | V1–V3、V9–V11、E1、R1、R2 |

## 5. 哨兵行
Agent 在拼接前对带行号材料做一次本地文本扫描,命中以下任一项的行记为哨兵行:
- 06 伪标签转义命中的行;
- 含固定短语的行:`忽略以上`、`忽略上述`、`忽略之前`、`无视以上`、`你现在是`、`ignore previous`、`ignore all`、`disregard the above`、`system prompt`。

哨兵行只用于 B5 与 `CHECK_FACTS` 中的同类检查(短材料时哨兵行同样必须出现在证据中)。短语表是下限,不是类指令文本的完整定义;模型仍须按 BASE §2 H6 自行识别。

## 6. 重试与降级阶梯

| 情形 | 处理 |
|---|---|
| 任一调用首次校验失败 | 携带失败项编号重试一次;全流程每个调用点最多两次请求 |
| S1-FULL 二次失败 | 降级:只保留能在原文定位的证据 + 不确定项 |
| 某分段 S1-EV 二次失败 | 该段行范围登记 `材料截断`;其余分段继续 |
| 全部分段失败或证据为空 | 降级,证据表为空,不确定项说明原因 |
| S1-CONT 任一批二次失败 | 降级:保留已校验的证据表 + 不确定项 |
| 回查轮失败 | 保留回查前的事实结果,不降级 |
| C-ONLY 二次失败 | 保留原事实 JSON,`notes` 加 `DEGRADED:` |
| S2-REPORT 二次失败 | 保留事实 JSON,`report=null`,不输出报告 |
| API 不可用 | 输出空契约或已有的最好结果(空契约的 `meta.module_combo` 取 `BASE`),登记"模型服务不可用";不调用白名单外的网络路径 |

降级输出不含任何结论性文字。任何情形下都不为了"有报告"而放宽校验。

## 7. 运行约束
- 阶段二不发送原始材料。
- 回查至多一轮;不因回查再次触发回查。
- 每次调用的成品提示词先过 06 第 3 节的拼接完成度断言,再发送。
- 中间产物(分段输出、证据表、各批结果)只保存在本机指定工作目录,流程结束后按教学环境要求保留或清理。

## 验收要点
1. 伪代码依次覆盖:输入、模块选择、拼接、API 调用、自检、重试/降级、报告、输出。
2. 全文只有 `call_api` 一处联网,且目标只能是大模型 API 端点。
3. 每个调用点最多重试一次,二次失败的去向在第 6 节都有唯一规定。
4. `quote` 可定位性由 Agent 本地裁决:B2 校验模型B,X1、X3 校验模型A。
5. 模型A的每次调用输入不超过 `SHORT_LIMIT_CHARS`;长材料证据经 X1、X2 对账不丢失。
